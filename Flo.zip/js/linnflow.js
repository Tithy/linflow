/**
 * Created by 1 on 2017/8/14.
 */

(function ($) {
    $.fn.iFlow = function (LinOption) {
        var LinBI = {
            //以下为该插件的属性及其默认值
            FloWidth: document.documentElement.clientWidth,
            /*randomNum:100,*/
            FloNum: Math.random() * (document.documentElement.clientWidth * 0.625 - 50 + 1) + 50,
            FloNode: $(".m-content-list").find(".m-content-item"),
            FLOTime:500
        };
        var LinOps = $.extend(LinBI, LinOption);

        var LinObj = function () {
            var FloW = LinOps.FloWidth;
            var FloN = LinOps.FloNum;
            var FloP = LinOps.FloNode;
            var FloT = LinOps.FLOTime;
            LinObj.prototype = {
                LinObjInit: function () {
                    this.LinCarryOut();
                },
                LinCarryOut: function () {
                    var LinObjThis = this;
                    $.each(FloP, function (index) {
                        LinObjThis.LinSetimgAuto($(FloP[index]), FloN, FloW);
                    });
                },
                LinSetimgAuto: function (LinP, LinN, LinW) {
                    var LinImgArray = [];
                    var LinX = 0;
                    var LinY = 0;
                    var LinList = "";
                    var LinImgH = LinN;
                    var LinFindImg = LinP.find(".s-imglist-none").find("img");
                    var LinFindImgLength = LinFindImg.length;
                    var LinSelfAppend;

                    /*没有照片停止*/
                    if (LinFindImgLength == 0) {
                        return false;
                    }

                    /*获取所有单项img*/
                    $.each(LinFindImg, function (index) {
                        LinImgArray.push(LinFindImg[index]);
                        LinFindImg[index].remove();
                    });

                    var LinAppend = function () {
                        if (LinP.find(".s-item-content img").length == 0) {
                            LinP.find(".s-item-content").append("<div class='m-item-list m-item-item" + LinY + "'></div>");
                        }

                        var LinM = LinY - 1;

                        /*填充方法*/
                        var LinSetAuto = function (LinSAN, LinSAW, LinSAImg, LinSAP) {
                            $.each(LinSAImg, function (index) {
                                LinSAImg[index].style.width = (LinSAImg[index].offsetWidth / LinSAW ) * (LinW ) -1 + "px";
                                LinSAImg[index].style.height = "auto";
                            });
                            /*设置每行图片高度统一*/
                            var LinSetDiv = LinSAN.find(".m-item-item" + LinSAP + "").height();
                            LinSAN.find(".m-item-item" + LinSAP + "").find("img").height(LinSetDiv)
                        };

                        /*判断是否填充满一行*/
                        var LinSizeLastRow = function () {

                            var LinLastRoW = 0;
                            var LinListRowImg = LinP.find(".m-item-item" + LinM + "").find("img");
                            $.each(LinListRowImg, function (index) {
                                LinLastRoW += Math.floor(LinListRowImg[index].offsetWidth);
                            });
                            LinSetAuto(LinP, LinLastRoW, LinListRowImg, LinM);

                        };

                        /*判断是否填充满过多*/
                        var LinSizeRow = function () {
                            /*单项添加*/
                            LinList += "<img src='" + LinImgArray[LinX].src + "' width='" + (LinImgH / (LinImgArray[LinX].height / LinImgArray[LinX].width) - 2) + "px" + "'>";
                            LinP.find(".m-item-item" + LinY + "").append(LinList);
                            LinP.find(".m-item-item" + LinY + "").find("img").css({
                                height: LinImgH + "px",
                            });
                            if (LinX < LinImgArray.length - 1) {
                                LinX++;
                            } else {
                                LinX = 0;
                            }
                            LinList = "";

                            var LinInitImgW = 0;
                            var LinListImg = LinP.find(".m-item-item" + LinY + "").find("img");

                            $.each(LinListImg, function (index) {
                                LinInitImgW += Math.floor(LinListImg[index].offsetWidth);
                                if (LinInitImgW >= LinW) {
                                    LinSetAuto(LinP, LinInitImgW, LinListImg, LinY);
                                    LinY++;
                                    LinP.find(".s-item-content").append("<div class='m-item-list m-item-item" + LinY + "'></div>");
                                }
                            });

                            if (LinP.find(".s-item-content img").length >= LinFindImgLength) {
                                LinM += 1;
                                LinSizeLastRow();
                                LinX = 0;
                                clearInterval(LinSelfAppend);
                                /*唤起Swiper*/
                                $(".s-item-content").on("click", "img", function () {
                                    var LinClickImg = $(this);
                                    if (typeof(LinOption.success) == "function") {
                                        LinOption.success(LinClickImg);
                                    }
                                });
                            }
                        };

                        LinSizeRow();
                    };
                    LinSelfAppend = setInterval(LinAppend, FloT);
                }
            };
            LinObj.prototype.LinObjInit();
        };
        LinObj();
    }
})(jQuery);

